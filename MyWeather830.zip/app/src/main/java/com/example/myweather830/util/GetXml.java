package com.example.myweather830.util;

import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.net.URL;
import java.util.Calendar;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class GetXml extends AsyncTask<String, Void, Document> {
    @Override
    protected Document doInBackground(String... strings) {
        Document doc = null;
        URL url;
        try {
            url = new URL(strings[0]);
            DocumentBuilderFactory dbf =
                    DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            doc = db.parse(new InputSource(url.openStream()));
            doc.getDocumentElement().normalize();
        }
        catch (Exception e) {
            Log.d("hack4ork", "에러 : " + e.getMessage());
            e.printStackTrace();
        }
        return doc;
    }

    @Override
    protected void onPostExecute(Document document) {
        super.onPostExecute(document);
        String s = "";
        NodeList nodeList = document.getElementsByTagName("data");
        Calendar cal = Calendar.getInstance();
        int year = cal.get(cal.YEAR);
        int month = cal .get(cal.MONTH)+1;
        int date = cal.get(cal.DATE);
        Log.d("calendar","year: "+year);
        Log.d("calendar","month: "+month);
        Log.d("calendar","date: "+date);


        for (int i=0; i<nodeList.getLength(); i++) {
            //s += i + ":";
            Node node = nodeList.item(i);
            Element fstElmnt = (Element) node;

            // 날짜, 시간, 온도, 습도, 강수확률, 날씨

            NodeList dayList = fstElmnt.getElementsByTagName("day");
            Element dayElement = (Element) dayList.item(0);
            dayList = dayElement.getChildNodes();
            String day = dayList.item(0).getNodeValue();

            switch (day){
                case "0":
                    s += "날짜 : "+year+"년 " + month+"월 "+date+"일 \n";
                    break;
                case "1":
                    s += "날짜 : "+year+"년 " + month+"월 "+(date+1)+"일 \n";
                    break;
                case "2":
                    s += "날짜 : "+year+"년 " + month+"월 "+(date+2)+"일 \n";
                    break;
            }


            NodeList hourList = fstElmnt.getElementsByTagName("hour");
            Element hourElement = (Element) hourList.item(0);
            hourList = hourElement.getChildNodes();
            String hour = hourList.item(0).getNodeValue();
            s +=hour+"시, ";

            NodeList tempList = fstElmnt.getElementsByTagName("temp");
            Element tempElement = (Element) tempList.item(0);
            tempList = tempElement.getChildNodes();
            String temp = tempList.item(0).getNodeValue();
            s += "온도:" + temp+", ";

            NodeList rehList = fstElmnt.getElementsByTagName("reh");
            Element rehElement = (Element) rehList.item(0);
            rehList = rehElement.getChildNodes();
            String reh = rehList.item(0).getNodeValue();
            s += "습도:" + reh+", ";

            NodeList popList = fstElmnt.getElementsByTagName("pop");
            Element popElement = (Element) popList.item(0);
            popList = popElement.getChildNodes();
            String pop = popList.item(0).getNodeValue();
            s += "습도:" + pop+", ";

            NodeList wfKorList = fstElmnt.getElementsByTagName("wfKor");
            Element wfKorElement = (Element) wfKorList.item(0);
            wfKorList = wfKorElement.getChildNodes();
            String wfKor = wfKorList.item(0).getNodeValue();
            s += "날씨:" + wfKor;
            s += "\n";


        }
        //weatherInfo.setText(s);
        Log.d("GetText","날씨 정보 : "+s);

    }


}
