package com.example.myweather830.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myweather830.R;
import com.example.myweather830.model.Weather;

import java.util.ArrayList;

public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.ViewHolder> implements OnWeatherItemClickListener {

    ArrayList<Weather> arrayList = new ArrayList<>();

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.weather_item,parent,false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Weather item = arrayList.get(position);
        holder.setItem(item);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    @Override
    public void onItemClick(ViewHolder holder, View view, int position) {

    }

    public void addItem(Weather item){
        arrayList.add(item);
    }



    static class ViewHolder extends RecyclerView.ViewHolder{

        TextView tv_date, tv_time, tv_wfKor,tv_temp,tv_reh,tv_pop;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_date = itemView.findViewById(R.id.tv_date);
            tv_time = itemView.findViewById(R.id.tv_time);
            tv_wfKor = itemView.findViewById(R.id.tv_wfKor);
            tv_temp=itemView.findViewById(R.id.tv_temp);
            tv_reh=itemView.findViewById(R.id.tv_reh);
            tv_pop=itemView.findViewById(R.id.tv_pop);

        }

        public void setItem(Weather item){
            tv_date.setText(item.getDate());
            tv_time.setText(item.getTime());
            tv_wfKor.setText(item.getWfKor());
            tv_temp.setText(item.getTemp());
            tv_reh.setText(item.getReh());
            tv_pop.setText(item.getPop());

        }



    }


}