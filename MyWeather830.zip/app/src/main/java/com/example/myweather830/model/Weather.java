package com.example.myweather830.model;

public class Weather {
    private String date;
    private String time;
    private String temp;
    private String reh;
    private String pop;
    private String wfKor;

    public Weather(String date, String time, String temp, String reh, String pop, String wfKor) {
        this.date = date;
        this.time = time;
        this.temp = temp;
        this.reh = reh;
        this.pop = pop;
        this.wfKor = wfKor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getReh() {
        return reh;
    }

    public void setReh(String reh) {
        this.reh = reh;
    }

    public String getPop() {
        return pop;
    }

    public void setPop(String pop) {
        this.pop = pop;
    }

    public String getWfKor() {
        return wfKor;
    }

    public void setWfKor(String wfKor) {
        this.wfKor = wfKor;
    }
}
