package com.example.myweather830.adapter;

import android.view.View;

public interface OnWeatherItemClickListener {
    public void onItemClick(WeatherAdapter.ViewHolder holder, View view, int position);

}
