package com.example.myweather830.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.myweather830.R;
import com.example.myweather830.util.GetXml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.net.URL;
import java.util.Calendar;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class WeatherActivity extends AppCompatActivity {
    Button weatherGetBtn;
    TextView weatherInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        weatherGetBtn = findViewById(R.id.weather_get_btn);
        weatherInfo = findViewById(R.id.weather_info);

        weatherGetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetXml task = new GetXml();
                task.execute("https://www.kma.go.kr/wid/queryDFS.jsp?gridx=89&gridy=90");
            }
        });
    }
}