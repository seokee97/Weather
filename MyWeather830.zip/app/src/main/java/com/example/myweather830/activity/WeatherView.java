package com.example.myweather830.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.myweather830.R;
import com.example.myweather830.adapter.WeatherAdapter;
import com.example.myweather830.model.Weather;

public class WeatherView extends AppCompatActivity {

    WeatherAdapter adapter;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_view);

        recyclerView = findViewById(R.id.rv_weather);
        LinearLayoutManager layoutManager =
                new LinearLayoutManager(this,
                        LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new WeatherAdapter();
            Weather weatherArr[] = new Weather[20];
            for(int i = 0; i<weatherArr.length;i++) {
                weatherArr[i] = new Weather("2020년 9월 5일", "15시", "24", "34", "34", "15");
                adapter.addItem(weatherArr[i]);
            }
        recyclerView.setAdapter(adapter);
        }
    }

